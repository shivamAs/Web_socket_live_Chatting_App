// Chat message model
export interface Message {
  text: string;
  username: string;
  avatar: string;
}
