package com.hselmi.websocketproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
